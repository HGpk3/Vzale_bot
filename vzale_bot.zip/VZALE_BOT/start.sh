#!/bin/bash
echo "Starting bot..."
python3 bot_admin_aiogram3.py
